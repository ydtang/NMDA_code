#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _CaE_reg();
extern void _CaP2_reg();
extern void _CaT_reg();
extern void _CalciumP_reg();
extern void _Currentstim_reg();
extern void _GammaStim_reg();
extern void _GammaStim1_reg();
extern void _K23_reg();
extern void _KA_reg();
extern void _KC3_reg();
extern void _KD_reg();
extern void _KM_reg();
extern void _Kh_reg();
extern void _Khh_reg();
extern void _Leak_reg();
extern void _NaF_reg();
extern void _NaP_reg();
extern void _PCNMDA_reg();
extern void _PfAMPA_reg();
extern void _RegulationStim_reg();
extern void _TimerescaleStim_reg();
extern void _TimerescaleStim1_reg();
extern void _cfAMPA_reg();
extern void _kebian_reg();
extern void _netstim_reg();
extern void _netstim1_reg();
extern void _pause_reg();

void modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," CaE.mod");
fprintf(stderr," CaP2.mod");
fprintf(stderr," CaT.mod");
fprintf(stderr," CalciumP.mod");
fprintf(stderr," Currentstim.mod");
fprintf(stderr," GammaStim.mod");
fprintf(stderr," GammaStim1.mod");
fprintf(stderr," K23.mod");
fprintf(stderr," KA.mod");
fprintf(stderr," KC3.mod");
fprintf(stderr," KD.mod");
fprintf(stderr," KM.mod");
fprintf(stderr," Kh.mod");
fprintf(stderr," Khh.mod");
fprintf(stderr," Leak.mod");
fprintf(stderr," NaF.mod");
fprintf(stderr," NaP.mod");
fprintf(stderr," PCNMDA.mod");
fprintf(stderr," PfAMPA.mod");
fprintf(stderr," RegulationStim.mod");
fprintf(stderr," TimerescaleStim.mod");
fprintf(stderr," TimerescaleStim1.mod");
fprintf(stderr," cfAMPA.mod");
fprintf(stderr," kebian.mod");
fprintf(stderr," netstim.mod");
fprintf(stderr," netstim1.mod");
fprintf(stderr," pause.mod");
fprintf(stderr, "\n");
    }
_CaE_reg();
_CaP2_reg();
_CaT_reg();
_CalciumP_reg();
_Currentstim_reg();
_GammaStim_reg();
_GammaStim1_reg();
_K23_reg();
_KA_reg();
_KC3_reg();
_KD_reg();
_KM_reg();
_Kh_reg();
_Khh_reg();
_Leak_reg();
_NaF_reg();
_NaP_reg();
_PCNMDA_reg();
_PfAMPA_reg();
_RegulationStim_reg();
_TimerescaleStim_reg();
_TimerescaleStim1_reg();
_cfAMPA_reg();
_kebian_reg();
_netstim_reg();
_netstim1_reg();
_pause_reg();
}
